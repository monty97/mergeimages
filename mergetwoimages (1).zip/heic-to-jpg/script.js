 function previewFiles() {
            const preview = document.getElementById('preview');
            preview.innerHTML = '';
            const files = document.getElementById('imageInput').files;
            if (files.length > 0) {
                preview.style.display = 'block';
                for (let i = 0; i < files.length; i++) {
                    const file = files[i];
                    const reader = new FileReader();
                    reader.onload = (function(file) {
                        return function(e) {
                            const img = document.createElement('img');
                            img.src = e.target.result;
                            preview.appendChild(img);
                            const p = document.createElement('p');
                            p.textContent = `Original Size: ${(file.size / 1024).toFixed(2)} KB`;
                            preview.appendChild(p);
                        };
                    })(file);
                    reader.readAsDataURL(file);
                }
            }
        }

        function convertToSelectedFormat() {
            const formatSelect = document.getElementById('formatSelect');
            const format = formatSelect.value;
            const output = document.getElementById('output');
            const files = document.getElementById('imageInput').files;
            const loading = document.getElementById('loading');

            output.innerHTML = '';
            loading.style.display = 'block'; // Show loading animation

            let filesProcessed = 0;

            for (let i = 0; i < files.length; i++) {
                const file = files[i];
                const reader = new FileReader();
                reader.onload = (function(file, format) {
                    return function(e) {
                        const img = new Image();
                        img.onload = function() {
                            const canvas = document.createElement('canvas');
                            canvas.width = img.width;
                            canvas.height = img.height;
                            const ctx = canvas.getContext('2d');
                            ctx.drawImage(img, 0, 0);
                            canvas.toBlob(function(blob) {
                                const url = URL.createObjectURL(blob);
                                const a = document.createElement('a');
                                a.href = url;
                                a.download = `converted-image.${format}`;
                                a.textContent = `Download ${file.name.split('.')[0]} as ${format.toUpperCase()}`;
                                output.appendChild(a);
                                const p = document.createElement('p');
                                p.textContent = `Converted Size: ${(blob.size / 1024).toFixed(2)} KB`;
                                output.appendChild(p);
                                
                                filesProcessed++;
                                if (filesProcessed === files.length) {
                                    loading.style.display = 'none'; // Hide loading animation when all files are processed
                                }
                            }, `image/${format}`);
                        };
                        img.src = e.target.result;
                    };
                })(file, format);
                reader.readAsDataURL(file);
            }
        }