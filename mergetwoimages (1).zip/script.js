function previewImage(inputId, previewId) {
            const input = document.getElementById(inputId);
            const preview = document.getElementById(previewId);
            const placeholder = document.getElementById('placeholder' + inputId[inputId.length - 1]);

            const file = input.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    preview.src = e.target.result;
                    placeholder.style.display = 'none';
                };
                reader.readAsDataURL(file);
            } else {
                preview.src = '';
                placeholder.style.display = 'block';
            }
        }

        function updateWidthValue(value) {
            document.getElementById('widthValue').textContent = value;
        }

        function updateHeightValue(value) {
            document.getElementById('heightValue').textContent = value;
        }

        function submitMerge() {
            const orientation = document.querySelector('input[name="orientation"]:checked').value;
            mergeImages(orientation);
        }

        function mergeImages(orientation) {
            const img1 = document.getElementById('preview1');
            const img2 = document.getElementById('preview2');
            const width = parseInt(document.getElementById('width').value);
            const height = parseInt(document.getElementById('height').value);
            const canvas = document.getElementById('resultCanvas');
            const context = canvas.getContext('2d');

            if (!img1.src || !img2.src) {
                alert('Please select both images.');
                return;
            }

            const img1Obj = new Image();
            const img2Obj = new Image();

            img1Obj.onload = function () {
                img2Obj.onload = function () {
                    if (orientation === 'vertical') {
                        canvas.width = width;
                        canvas.height = height * 2;
                        context.drawImage(img1Obj, 0, 0, width, height);
                        context.drawImage(img2Obj, 0, height, width, height);
                    } else {
                        canvas.width = width * 2;
                        canvas.height = height;
                        context.drawImage(img1Obj, 0, 0, width, height);
                        context.drawImage(img2Obj, width, 0, width, height);
                    }
                    document.getElementById('download').style.display = 'block';
                };
                img2Obj.src = img2.src;
            };
            img1Obj.src = img1.src;
        }

        function downloadImage() {
            const canvas = document.getElementById('resultCanvas');
            const format = document.getElementById('format').value;
            const link = document.getElementById('download');

            link.href = canvas.toDataURL('image/' + format);
            link.download = 'merged_image.' + format;
        }

        function updateDownloadFormat() {
            const format = document.getElementById('format').value;
            const downloadButton = document.getElementById('download');
            downloadButton.download = `merged_image.${format}`;
        }

        function toggleMenu() {
            const menu = document.querySelector('.nav-menu.mobile');
            menu.classList.toggle('show');
        }